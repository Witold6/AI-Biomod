sequence-translator
===================

Translate DNA or RNA sequences to protein sequences by using the "standard" genetic code. 

Compilation requirements
-------------
- A C++ compiler
- [Boost C++ Libraries](http://www.boost.org)
