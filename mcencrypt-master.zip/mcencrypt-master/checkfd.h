#ifndef __CHECKFD_H____
#define __CHECKFD_H____

#include <poll.h>

extern int checkfd(int, short);

#endif
