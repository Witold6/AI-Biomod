#ifndef _FSYNCDF_H___
#define _FSYNCDF_H___

extern int fsyncfd(int);

#endif
