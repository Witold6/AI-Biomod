#ifndef crypto_hash_sha512_H
#define crypto_hash_sha512_H

#define crypto_hash_sha512_BYTES 64
extern int crypto_hash_sha512(unsigned char *, const unsigned char *, unsigned long long);

#endif
