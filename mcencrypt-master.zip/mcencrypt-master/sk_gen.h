#ifndef SK_GEN_H
#define SK_GEN_H

#include "gf.h"

int sk_gen(unsigned char *);

#endif

