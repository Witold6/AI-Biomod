#ifndef _RANDOMBYTES_H____
#define _RANDOMBYTES_H____

extern void randombytes(void *, unsigned long long);

#endif
