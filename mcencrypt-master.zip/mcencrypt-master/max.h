#ifndef _MAX_H____
#define _MAX_H____

/* 2^62 */
#define MAX 4611686018427387904ULL

#endif
