#ifndef _LIMITS_H____
#define _LIMITS_H____

extern void limits(void);

#endif
