#ifndef _MEMREADALL_H____
#define _MEMREADALL_H____

extern unsigned char *memreadall(unsigned long long *, int);

#endif
