#ifndef _READBLOCK_H____
#define _READBLOCK_H____

extern long long readblock(int fd, void *x, long long len);

#endif
