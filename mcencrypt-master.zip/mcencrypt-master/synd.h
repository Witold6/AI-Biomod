#ifndef SYND_H
#define SYND_H

#include "gf.h"

void synd(gf *, gf *, gf *, unsigned char *);

#endif

