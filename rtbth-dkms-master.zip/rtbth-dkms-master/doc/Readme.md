
The user guide is outdated but can be still useful
 to understand how the driver works.

