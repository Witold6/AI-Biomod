
## Firmware upgrade ##

_if you feel adventurous enough_

`rtbt` binary blob contains an outdated firmware version
 (3298LE.Feb 02 2012.14:54:49).

With the `upgrade-firmware.sh` tool you can upgrade the blob to a newer one
 (3298LE.Apr 16 2014.21:48:11) provided here.

WARNING: it's possible to use another `rt3298.bin` image
 but it's length should be exactly 40955 bytes!
 You can cut excess null bytes at the end if length is bigger.
