# 2015 Lopez Jr

The Python code for Lopez Jr, team 4009's Recycle Rush bot, now award-winning, totes official and tested
in the heat of three competitions.
The masses know our bot as Lambda Larry, our way of respecting one of the largest contributors
to our team.
The name Lopez Jr. has originated from the eleventh season of the popular
webseries Red v. Blue, since it's a robot & we already have a Lopez - Media
captain Matt. It's a nice robot, and I'm glad we can run Python on it.
-Nik
