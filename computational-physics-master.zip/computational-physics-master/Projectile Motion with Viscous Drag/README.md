# Newtonian Projectile Motion with Viscous Drag

_More details to come. Project undocumented_