# Hacker's Guide to Neural Networks - Python Code

A Python implementation of the code in Andrej Karpathy's *[Hacker's Guide to Neural Networks](https://karpathy.github.io/neuralnets/)*, an introduction to basic machine learning concepts.