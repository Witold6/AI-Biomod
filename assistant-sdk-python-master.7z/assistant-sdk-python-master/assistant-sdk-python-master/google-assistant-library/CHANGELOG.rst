Changelog
=========

1.0.1
-----
- Limited support with no hotwording for ARMv6 architecture (Raspberry Pi Zero).
- Many improvements to media playback for better performance.
- Fixed issues with registration.
- Ensure clean shutdown when Python exception is raised.

1.0.0
-----
- Support for additional languages. This includes hotword models, queries, and responses.
- Support for playing news and podcasts.
- Support for broadcasting voice messages.

0.1.1
-----
- Fix remote casting to Cast-enabled devices.


0.1.0
-----
- Add support for device actions.
- Better handling of connection errors.


0.0.3
-----
- Support for x86_64 Linux
- Support for Python 2.7
- Bug fixes and improvements in error messaging


0.0.2
-----
- Initial public release.
