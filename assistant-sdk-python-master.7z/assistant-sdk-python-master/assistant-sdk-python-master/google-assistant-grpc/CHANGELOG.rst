Changelog
=========

0.2.1
-----
- Update ``v1alpha2`` gRPC service definition:
  - Add new fields for AoG testing/debugging.


0.2.0
-----
- Update ``v1alpha2`` gRPC service definition:
  - Add ScreenOut/ScreenOutConfig message.
  - Add is_new_conversation field.


0.1.0
-----
- Add ``v1alpha2`` gRPC service definition.


0.0.2
-----
- Bump ``grpcio`` dependency to use binary wheels (faster install on ``armv7l``).


0.0.1
-----
- Initial release.
