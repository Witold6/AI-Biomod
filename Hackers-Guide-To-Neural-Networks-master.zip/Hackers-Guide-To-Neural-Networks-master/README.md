# Hackers-Guide-To-Neural-Networks
Machine Learning Work (Andrej Karpathy's Blog on Neural Networks translated to Python &amp; Backpropagation )
