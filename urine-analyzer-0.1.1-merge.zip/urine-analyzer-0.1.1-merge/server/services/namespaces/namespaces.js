Services = {}
Services.type = {}
Services.status = {}
Services.utils = {}
Services.msp = {}
Services.msp.methods = {}
Services.rpi = {}
Services.rpi.methods = {}