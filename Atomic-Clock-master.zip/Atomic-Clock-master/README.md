# Atomic-Clock
A simple atomic clock that pulls data from a server and displays it on a Java Swing JFrame

Edit:
The program no longer works at the moment since the server that the program uses to pull time data has been taken down. Will be updated and fixed later.
