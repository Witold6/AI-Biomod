pyxhook is an implementation of pyhook (http://sourceforge.net/projects/pyhook/) that works on Linux

It is taken from: https://github.com/JeffHoogland/pyxhook
