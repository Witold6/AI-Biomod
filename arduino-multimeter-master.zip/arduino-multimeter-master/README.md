# arduino-multimeter
Dual channel voltmeter + ampermeter built with Arduino
