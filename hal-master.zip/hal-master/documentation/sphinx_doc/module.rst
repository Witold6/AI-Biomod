Module
=======

.. autoclass:: hal_py.module
   :members:
   :inherited-members:
   :show-inheritance:
