Gate Decorator
=============================

.. autoclass:: hal_py.gate_decorator
   :members:
