Interface GUI
============================

.. autoclass:: hal_py.i_gui
   :members:
