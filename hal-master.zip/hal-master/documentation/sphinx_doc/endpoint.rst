Endpoint
==========================

.. autoclass:: hal_py.endpoint
   :members:
   :undoc-members:
