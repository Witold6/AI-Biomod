HAL Path
==========================

.. autoclass:: hal_py.hal_path
   :members:
