Gate
==========================

.. autoclass:: hal_py.gate
   :members:
   :inherited-members:
   :show-inheritance:
