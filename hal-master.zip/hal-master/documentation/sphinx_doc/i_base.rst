Interface Base
=============================

.. autoclass:: hal_py.i_base
   :members:
