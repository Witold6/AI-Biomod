Plugin Manager
=====================

.. automodule:: hal_py.plugin_manager
   :members:
