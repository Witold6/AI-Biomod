Graph Algorithm
==========================

.. autoclass:: hal_plugins.libgraph_algorithm.graph_algorithm
   :members:
