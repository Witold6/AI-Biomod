Netlist
==========================

.. autoclass:: hal_py.netlist
   :members:
