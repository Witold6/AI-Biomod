hal_py Documentation
=====================

.. toctree::
   :maxdepth: 1

   core_utils
   data_container
   gate_library
   endpoint
   netlist
   gate
   net
   module
   path
   i_base
   i_gui
   bdd
   gate_decorator
   gate_decorator_bdd
   gate_decorator_lut
   gate_decorator_system
   plugin_manager
   netlist_factory
   hdl_writer_dispatcher
   graph_algorithm
