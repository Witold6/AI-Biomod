Net
==========================

.. autoclass:: hal_py.net
   :members:
   :inherited-members:
   :show-inheritance:
