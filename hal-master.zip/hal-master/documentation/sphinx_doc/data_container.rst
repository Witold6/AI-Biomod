Data Container
==========================

.. autoclass:: hal_py.data_container
   :members:
