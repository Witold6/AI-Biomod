Gate Decorator BDD
================================

.. autoclass:: hal_py.gate_decorator_bdd
   :members:
