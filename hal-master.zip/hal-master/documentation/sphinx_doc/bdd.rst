BDD
==========================

.. autoclass:: hal_py.bdd
   :members:
