Gate Decorator System
=====================

.. automodule:: hal_py.gate_decorator_system
   :members:
