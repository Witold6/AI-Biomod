gate_decorator_system Documentation
========================================

.. autoclass:: hal_py.gate_decorator_system
    :members:
    :undoc-members: