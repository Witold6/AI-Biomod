bdd Documentation
============================

.. autoclass:: hal_py.bdd
    :members:
    :undoc-members: