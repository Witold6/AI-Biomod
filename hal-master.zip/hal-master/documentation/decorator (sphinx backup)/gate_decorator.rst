gate_decorator Documentation
========================================

.. autoclass:: hal_py.gate_decorator
    :members:
    :undoc-members: