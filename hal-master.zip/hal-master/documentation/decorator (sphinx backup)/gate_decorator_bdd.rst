gate_decorator_bdd Documentation
========================================

.. autoclass:: hal_py.gate_decorator_bdd
    :members:
    :undoc-members: