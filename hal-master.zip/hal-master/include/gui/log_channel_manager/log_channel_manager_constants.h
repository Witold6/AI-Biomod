#ifndef LOG_CHANNEL_MANAGER_CONSTANTS_H
#define LOG_CHANNEL_MANAGER_CONSTANTS_H

namespace log_channel_manager_constants
{
static const int max_channels = 50;
static const int max_entries = 1000;
}

#endif // LOG_CHANNEL_MANAGER_CONSTANTS_H
