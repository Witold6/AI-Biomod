#ifndef UTILITY_ITEM_H
#define UTILITY_ITEM_H


class utility_item
{
public:
    utility_item();
};

#endif // UTILITY_ITEM_H