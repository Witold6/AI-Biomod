#ifndef NETLIST_ITEM_H
#define NETLIST_ITEM_H


class netlist_item
{
public:
    netlist_item();
};

#endif // NETLIST_ITEM_H