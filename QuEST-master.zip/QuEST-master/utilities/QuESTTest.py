#!/usr/bin/env python3

import os.path
exec(open(os.path.join(os.path.dirname(__file__),"QuESTTest/__main__.py")).read())
