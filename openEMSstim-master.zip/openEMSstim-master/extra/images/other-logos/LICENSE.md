All these logos are in public domain or other form of license that allows for teir dissemination. We do not retain any rights for these logos or trademarks. 
