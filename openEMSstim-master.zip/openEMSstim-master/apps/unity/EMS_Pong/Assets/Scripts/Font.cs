﻿using UnityEngine;
using System.Collections;

public class Font : MonoBehaviour {

	// Use this for initialization
	void Start () {
		QualitySettings.antiAliasing = 8;
	}

}
