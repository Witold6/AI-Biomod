class Preset:
    intensity = 0
    name = "undefined"

    def __init__(self,intensity, name):
        self.intensity = intensity
        self.name = name
