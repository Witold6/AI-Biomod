# 转载声明
本软件为开源软件，开发者即为 [@elliottzheng](https://github.com/elliottzheng)，软件无任何收费，欢迎STAR，PR。

**欢迎转发，转发无需告知作者，但请一定附上项目地址**。
::: warning

未附上项目地址的软件转载行为均无授权

项目地址为：[https://github.com/copytranslator/CopyTranslator](https://github.com/copytranslator/CopyTranslator)
:::


目前已授权
1. 吾爱破解网友`@zhengchengyy`发布软件更新消息。
2. 微信公众号：简单生活干货铺、哼哈未来，AI科技大本营
3. **附上项目地址的文章。**

::: danger
有一些公众号无授权转载（**未附上项目地址**）本软件以期获取关注，甚至**出售此软件**，我不想在这里点名批评，没啥意义，只是觉得本来就是免费的开源软件，只要加个项目地址，大家都开开心心的，他们的行为让人不齿而已，如果有看到这种情况，大家可以告知我，虽然我好像也不能怎么样。
:::


