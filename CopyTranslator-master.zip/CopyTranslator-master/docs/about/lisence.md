# 开源协议
代码采用GNU GENERAL PUBLIC LICENSE 2.0协议授权。请查阅[LICENSE](https://github.com/copytranslator/copytranslator/blob/master/LICENSE) 文件，获取更多信息。