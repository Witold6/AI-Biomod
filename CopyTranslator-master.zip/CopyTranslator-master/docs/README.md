---
home: true
heroImage: /icon.png
actionText: 快速上手 →
actionLink: /download/
features:
- title: 复制即翻译
  details: 只需复制文本到剪贴板，下一秒即可查看翻译结果，享受所见即所得的快感。
- title: 自动格式化
  details: 解决多余的断句和换行带来的乱码问题，翻译结果更符合阅读习惯。
- title: 拖拽复制
  details: 无限接近划译的系统级开源实现，拖拽选中即可复制翻译。
footer: GPL v2 Licensed | Copyright © 2019-present Elliott Zheng
---

