npm
<template>
  <div id="app" class="application">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App"
};
</script>
<style>
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

body {
  margin: 0%;
  overflow: hidden;
}

#nav {
  padding: 30px;
}

::-webkit-scrollbar {
  display: none;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
