To modify the font icons (e.g. add your own icons), drag and drop the
config.json to http://fontello.com/. Follow the fontello instructions
for more info.