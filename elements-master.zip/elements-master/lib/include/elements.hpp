/*=============================================================================
   Copyright (c) 2016-2019 Joel de Guzman

   Distributed under the MIT License [ https://opensource.org/licenses/MIT ]
=============================================================================*/
#if !defined(ELEMENTS_FERBRUARY_17_2017)
#define ELEMENTS_FERBRUARY_17_2017

#include <elements/app.hpp>
#include <elements/window.hpp>
#include <elements/view.hpp>
#include <elements/element.hpp>

#endif