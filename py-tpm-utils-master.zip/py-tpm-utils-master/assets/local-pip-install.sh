#!/usr/bin/env bash
pip install --upgrade --find-links=. .

