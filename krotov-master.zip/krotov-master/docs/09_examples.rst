.. _krotov-example-notebooks:

========
Examples
========

.. raw:: html

    <a href="http://nbviewer.jupyter.org/github/qucontrol/krotov/blob/master/docs/notebooks" target="_blank"><img alt="Render on nbviewer" src="https://img.shields.io/badge/render%20on-nbviewer-orange.svg" style="vertical-align:text-bottom"></a>&nbsp;<a href="https://mybinder.org/v2/gh/qucontrol/krotov/master?filepath=docs%2Fnotebooks" target="_blank"><img alt="Launch Binder" src="https://mybinder.org/badge_logo.svg" style="vertical-align:text-bottom"></a>

.. toctree::
    :maxdepth: 1
    :glob:

    notebooks/*
