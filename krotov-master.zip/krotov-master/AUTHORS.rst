=======
Credits
=======

Development Lead
----------------

* `Michael Goerz`_ <mail@michaelgoerz.net>


Development Team
----------------

* Daniel Basilewitsch <basilewitsch@physik.uni-kassel.de>
* Fernando Gago Encinas <fernando.gago@physik.uni-kassel.de>
* Matthias Krauss <matthias.krauss@physik.uni-kassel.de>
* Karl Horn <karlhorn@physik.uni-kassel.de>
* `Daniel Reich`_ <daniel.reich@physik.uni-kassel.de>
* `Christiane Koch`_ <christiane.koch@uni-kassel.de>

.. _Michael Goerz: https://michaelgoerz.net
.. _Daniel Reich: https://www.uni-kassel.de/fb10/en/institutes/physics/research-groups/quantum-dynamics-and-control/group-members/dr-daniel-reich.html
.. _Christiane Koch: https://www.uni-kassel.de/fb10/en/institutes/physics/research-groups/quantum-dynamics-and-control/homepage.html


Acknowledgements
----------------

We thank `@uiofgh`_, `@nathanshammah`_, and `@TejasAvinasShetty`_ for reporting
bugs and suggesting improvements.

.. _@uiofgh: https://github.com/uiofgh
.. _@nathanshammah: https://github.com/nathanshammah
.. _@TejasAvinasShetty: https://github.com/TejasAvinashShetty
