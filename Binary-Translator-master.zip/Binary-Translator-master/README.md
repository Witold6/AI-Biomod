# Binary-Translator
This is a simple binary translator made in python
