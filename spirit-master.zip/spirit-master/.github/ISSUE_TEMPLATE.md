<!--
    This is an issue template.
    
    For bug reports, please ALWAYS attach the Log file the code produced when the issue occurred
    (ideally with maximum log levels) and list the following:
    - Bug description
    - Steps to reproduce
    - Code version and, if possible, git revision hash
    - System information, such as operating system, compiler version, GPU (if using the CUDA backend)

    For feature suggestions etc. nothing special is needed.
-->