#ifndef COLORMAP_BLACK_GLSL_HXX
#define COLORMAP_BLACK_GLSL_HXX

static const std::string COLORMAP_BLACK_GLSL = R"LITERAL(
vec3 colormap(vec3 direction) {
     return vec3(0.0, 0.0, 0.0);
}
)LITERAL";

#endif

