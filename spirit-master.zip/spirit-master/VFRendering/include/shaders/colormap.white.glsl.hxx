#ifndef COLORMAP_WHITE_GLSL_HXX
#define COLORMAP_WHITE_GLSL_HXX

static const std::string COLORMAP_WHITE_GLSL = R"LITERAL(
vec3 colormap(vec3 direction) {
     return vec3(1.0, 1.0, 1.0);
}
)LITERAL";

#endif

