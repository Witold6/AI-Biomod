Spirit Python Library
=====================

See https://spirit-code.github.io

For API documentations for this package, see
https://spirit-docs.readthedocs.io