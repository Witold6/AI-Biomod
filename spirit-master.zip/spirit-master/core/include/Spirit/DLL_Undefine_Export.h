/*
    This header, included at the end of API headers,
    prevents the leakage of the defines to code which includes these headers
*/

#undef PREFIX
#undef SUFFIX