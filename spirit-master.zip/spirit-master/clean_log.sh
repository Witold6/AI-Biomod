rm Log*.txt
