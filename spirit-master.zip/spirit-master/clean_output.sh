find ./output ! -name .gitkeep ! -wholename ./output -delete
