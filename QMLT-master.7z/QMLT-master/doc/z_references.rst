References and further reading
===============================

Further reading
---------------

For more details and further information on machine learning, optimization, quantum optical circuits, and quantum machine learning, please see the following:

(Coming soon.)

.. bibliography:: references.bib
	:style: unsrt
	:labelprefix: FR
	:filter: key % "FR-"

References
----------

.. bibliography:: references.bib
	:cited:
	:style: unsrt
   
