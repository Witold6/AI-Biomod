#ifndef OPEN_DSO_150_H
#define OPEN_DSO_150_H

void dsosetup();
void dsoloop();

#endif
