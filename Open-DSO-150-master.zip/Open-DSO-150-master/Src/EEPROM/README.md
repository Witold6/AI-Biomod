# EEPROM emulation STM32 series library
<br />
I hope use it and enjoy.
<br />
I use Stm32f103C8 and Keil Compiler and Stm32CubeMX wizard.
 <br />
 I only test On this chip yet.
 <br />
Please Do This ...
<br />
<br />
1) Select "General peripheral Initalizion as a pair of '.c/.h' file per peripheral" on project settings.
<br />
2) Config your EEPROMConfig.h file.
<br />



