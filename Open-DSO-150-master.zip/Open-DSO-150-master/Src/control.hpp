#ifndef CONTROL_H
#define CONTROL_H

void controlLoop();
void captureDisplayCycle(bool wTimeOut);

#endif
