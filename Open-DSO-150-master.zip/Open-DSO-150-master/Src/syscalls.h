/*
 * syscalls.h
 *
 *  Created on: Feb 21, 2018
 *      Author: Michael Hartmann
 */

#ifndef SYSCALLS_H_
#define SYSCALLS_H_

int _write(int file, char *data, int len);



#endif /* SYSCALLS_H_ */
