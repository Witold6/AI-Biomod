function [ gama ] = getNoiseIntensity()
%GETNOISEINTENSITY Inputs the user for the gama operator (noise intensity)

    disp('Input the desired intensity of the noise');
    disp('Default is 0.00');
    gama = input('> ');

end

