//
//  AppDelegate.h
//  OpenSpirometry
//
//  Created by Eric Larson on 6/1/15.
//  Copyright (c) 2015 Eric Larson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

