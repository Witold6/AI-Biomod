This folder contains a python library used by px_process_module_doc.py
